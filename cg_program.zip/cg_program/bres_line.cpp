#include<GL/glut.h>
#include<iostream>
#include<math.h>
using namespace std;

float r,g,b,x,y;
float x_1,x_2,y_1,y_2;
float length;
bool flag = true;

void mouse(int button , int state , int mousex , int mousey)
{
	if (button == GLUT_LEFT_BUTTON && GLUT_DOWN)
	{
		flag = true;
		x = mousex;
		y = 640-mousey;
	}
	
	cout<< "mousex = "<<x;
	cout<< "mousey = "<<y;
}

void Line(){
	cout<<"X_1= "<<x_1<<"Y_1= "<<y_1;
	cout<<"X_1= "<<x_2<<"Y_1= "<<y_2;
	
	float dy, dx, length, G;
	
	//x_2 = x;
	//y_2 = y;
	dy = y_2-y_1;
	dx = x_2-x_1;	
	G = (2*dy)-dx;
	if(abs(dx) >= abs(dy)){
		length = abs(dx);
	}
	else{
		length = abs(dy);
	}
	
	int j = 0;
	x = x_1;
	y = y_1;
	
	while(j<= length){
		if(abs(dx) >= abs(dy)){
			x = x+1;
				if(G>=0)
				{
					y = y+1;
					G = G+2*(dy-dx);
				}
				else{
					G = G + 2*(dy-dx);
				}
		}
		else{
			y = y+1;
			if(G>=0){
				x=x+1;
				G = G + 2*(dy-dx);
			}
			else{
				G = G + (2*dy);
			}
		}
                
     		cout<<"|n X = "<<x;
		cout<<"|n Y = "<<y;
		glBegin(GL_POINTS);
		glVertex2i(x,y);
		glEnd();
		j++;
	}
	glFlush();
}

void init(void)
{
	glClearColor(0,0,0,0);
	glColor3f(1.0,1.0,0.0);
	gluOrtho2D(0,640,0,640);
	glClear(GL_COLOR_BUFFER_BIT);
}

int main(int argc , char** argv)
{
	cout<<"Enter x1 and y1 points : ";
	cin>>x_1>>y_1;
	cout<<"Enter x2 and y2 points : ";
	cin>>x_2>>y_2;
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(0,640);
	glutCreateWindow("Bresenham Line");
	init();
	//glutMouseFunc(mouse);
	glutDisplayFunc(Line);
	glutMainLoop();
	
	return 0;
}

